$(document).ready(function () {
     initializeMenu();
    initializeStickerSelectionHandler();
     initializeButtons();
     attachFileDragAndDropHandlers();
    // enablePositionLogging();
});

/* Перемещение кнопками */
$(document).keyup(function (eventObject) {
    let key = eventObject.which;

    let target = $(".selected");
    let targetXY = target.offset();
    let targetY = targetXY.top;
    let targetX = targetXY.left;
    let carXY = $("#drop-box").offset();
    let carY = carXY.top;
    let carX = carXY.left;
    let car = $("#drop-box");
    console.log(targetX);
    console.log(carX);


    switch (key) {
        case 37: {
            if((targetX-10)>carX){
            target.offset({top:targetY, left:(targetX-10)})};
            break;
        }
        case 38: {
           if((targetY-10)>carY){
            target.offset({top:(targetY-10), left:targetX})};
            break;
        }
        case 39: {
            if((targetX+target.width()+10)<(carX+car.width())){
            target.offset({top:targetY, left:(targetX+10)})};
            break;
        }
        case 40: {
            if((targetY+target.height()+10)<(carY+car.height())){
            target.offset({top:(targetY+10), left:targetX})};
            break;
        }
    }
});

/* Инициализация кнопок */
function initializeButtons() {
    $("input")[3].onclick = function () {
        let target = $(".selected")[0];
        let targetWidth = target.width;
        $(".selected").css("width", targetWidth * 1.3).css("margin-bottom", -targetWidth*1.3);
    };
    $("input")[4].onclick = function () {
        let target = $(".selected")[0];
        console.log(target);
        let targetWidth = target.width;
        console.log(targetWidth);
        if(target.width>30){
            console.log(target.width);
        $(".selected").css("width", targetWidth - (targetWidth * 0.3)).css("margin-bottom", -targetWidth*1.3)};
    };
    $("input")[5].onclick = function () {
        let target = $(".selected")[0];
        let targetHeight = target.height;

        $(".selected").css("height", targetHeight * 1.3);
    };
    $("input")[6].onclick = function () {
        let target = $(".selected")[0];
        let targetHeight = target.height;
        if(target.height>30){
        $(".selected").css("height", targetHeight - (targetHeight * 0.3))}
    };
}
/* Инициализация меню */
function initializeMenu() {
    $("menu ul li input").click(function() {
        let currentIndex = $(this).parent().index();

        $("*").removeClass("active");
        $(this).parent().addClass("active");

        $("menu ul:not(:first-child)").css("display", "none");
        $("menu ul:not(:first-child)")[currentIndex].style.display = "block";

    })
}
// /* Лог передвижения наклейки */
// function enablePositionLogging() {
//     $("menu li:not(:first-child)").on("drag", function () {
//         //console.log("Координаты объекта (" + $(this).find("img")[0].alt + "): " + $(this).find("img")[0].x + " " + $(this).find("img")[0].y);
//     });
// }

/* Замена изображений в блоке с приорой */
function attachFileDragAndDropHandlers() {

    $(".drop-area").on("dragenter", function() {
        $(this).css("background-color", "lightgray");
    }).on("dragleave", function(){
        $(this).css("background-color", "");
    }).on("dragover", false);

    $(".drop-area")[0].ondrop = function (event) {
        event.preventDefault();
        let file = event.dataTransfer.files[0];
        let filereader = new FileReader();

        filereader.onload = function (event) {
            console.log(1);
            $("figure img:first-of-type").attr("src", filereader.result);
        };
        filereader.readAsDataURL(file);

        $(this).css("background-color", "");
    };
}

/* Выделение объектов */
function initializeStickerSelectionHandler() {
   $("menu ul:not(:first-child) li img")
   .on("dragend", function(event){
        let selected = false;
        let height=$(this).height();
        let width=$(this).width();
        event.preventDefault();
        let cursorX = event.pageX;
        let cursorY = event.pageY;
        let coord=$("#drop-box").offset();
        $(this).clone().appendTo("#drop-box")
        .css("position","absolute")
        .offset({top:cursorY, left:cursorX})
        .height(height)
        .width(width)
        .click(function(){
            if(selected){
                $(this).removeClass("selected")
                selected = false;
            }
            else{
                $("*").removeClass("selected");
                $(this).addClass("selected")
                selected = true;
            }
    })
        let currentIndex = $("menu ul:first-child li.active").index();
        if (currentIndex!=2){
        $("menu ul:not(:first-child)")[currentIndex].style.display = "none";
        $("menu ul:first-child li.active").css("display", "none")
        }
        else{
            if($("#drop-box img[alt ~= 'Диск']").length>1){
                $("menu ul:not(:first-child)")[currentIndex].style.display = "none";
                $("menu ul:first-child li.active").css("display", "none")}
        }

   })

}
